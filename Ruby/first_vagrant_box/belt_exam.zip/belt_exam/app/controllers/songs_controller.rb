class SongsController < ApplicationController
    def index
        @songs = Song.all
        
    end

  def create
    @song = Song.new song_params
    unless @song.save
      flash[:errors]= @song.errors.full_messages
    end
    redirect_to '/songs'
  end

  def show
      
      @song = Song.includes(:user, :playlist_songs).find(params[:id])
      
  end

  private
    def song_params
      params.require(:song).permit(:artist, :title)
    end
    end

    

